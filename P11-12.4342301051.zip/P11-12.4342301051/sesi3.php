<?php
session_start();
$user=$_SESSION["username"];
$pass=$_SESSION["password"];
?>


   
<!DOCTYPE html>
<html>
    <body>
        <?php
        echo "username: " .$user. ".<br>";
        echo "password: " .$pass. ".";

        echo "<h2>Hapus SESSION klik <a href='sesi4.php'>disini</h2>";
            ?>
    </body>
</html>
