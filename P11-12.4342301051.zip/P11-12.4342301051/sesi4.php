<?php
session_start();
session_unset();
session_destroy();
?>
   
<!DOCTYPE html>
<html>
    <body>
        <h3>Sesi Telah Di Hapus</h3>
</body>
</html>