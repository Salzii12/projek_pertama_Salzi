<?php
// include database connection file
include 'koneksi.php';
$kode= $_POST['kode'];
$makul=$_POST['makul'];
$dosen=$_POST['dosen'];
$ruang=$_POST['ruang'];
$hari=$_POST['hari'];
$result = mysqli_query($koneksi, "UPDATE jadwal SET
makul='$makul',dosen='$dosen',ruang='$ruang',hari='$hari' WHERE kode='$kode'");
// Redirect to homepage to display updated user in list
header("Location: daftar_jadwal.php");
?>