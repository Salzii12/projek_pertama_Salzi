<?php
include 'koneksi.php';
$kode = $_POST['kode'];
$makul = $_POST['makul'];
$dosen = $_POST['dosen'];
$ruang= $_POST['ruang'];
$hari = $_POST['hari'];
$input = mysqli_query($koneksi,"INSERT INTO jadwal
VALUES('$kode','$makul','$dosen','$ruang','$hari')") or die(mysql_error());
if($input){
echo "Data Berhasil Disimpan";
header("location:daftar_jadwal.php");
}else{
echo "Gagal Disimpan";
}
?>