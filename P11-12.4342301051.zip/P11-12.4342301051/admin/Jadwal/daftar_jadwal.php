<?php
session_start();
if (!isset($_SESSION["user"])){
    header("location: login.php");
    exit;
}

$user=$_SESSION['user'];
?>


<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="../Boostrap/css/bootstrap.min.css" >
<link rel="stylesheet" type="text/css" href="admin.css">
<link rel="stylesheet" type="text/css" href="../Boostrap/fontawesome/css/all.min.css">
<title>ADMINISTRATOR</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top">
<a class="navbar-brand" href="#">SELAMAT DATANG <?php echo $user;?></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" datatarget="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<form class="form-inline my-2 my-lg-0 ml-auto">
    <button class="btn btn-danger"><a href="tambah_jadwal.php">Tambah Jadwal</a></button>       
</form>
<div class="icon ml-4">
<h5>
<i class="fas fa-envelope-square mr-3"></i>
<i class="fas fa-bell-slash mr-3"></i>
<i class="fas fa-sign-out-alt mr-3"></i>
</h5>
</div>
</div>
</nav>
<div class="row no-gutters mt-5">
<div class="col-md-2 bg-dark mt-2 pr-3 pt-4">
<ul class="nav flex-column ml-3 mb-5">
<li class="nav-item">
<a class="nav-link active text-white" href="../Dosen/daftar_dosen.php"><i class="fas fa-tachometer-alt mr2"></i>Daftar Dosen</a><hr class="bg-secondary">
</li>
<li class="nav-item">
<a class="nav-link text-white" href="../Mahasiswa/index.php"><i class="fas fa-user-graduate mr-2"></i>Daftar
Mahasiswa</a><hr class="bg-secondary">
</li>
<li class="nav-item">
<a class="nav-link text-white" href="../Pegawai/daftar_pegawai.php" ><i class="fas fa-users mr-2"></i>Daftar Pegawai</a><hr
class="bg-secondary">
</li>
<li class="nav-item">
<a class="nav-link text-white" href="../Jadwal/daftar_jadwal.php" ><i class="far fa-calendar-alt mr-2"></i>Jadwal Kuliah</a><hr
class="bg-secondary">
</li>
</ul>
</div>
<div class="col-md-10 p-5 pt-2">
<h3><i class="fas fa-user-graduate mr-2"></i> Input Jadwal Baru</h3><hr>
<table class="table table-striped table-bordered">
    <thead>
        <tr?>
            <th scope="col">NO</th>
            <th scope="col">KODE</th>
            <th scope="col">MAKUL</th>
            <th scope="col">DOSEN</th>
            <th scope="col">RUANG</th>
            <th scope="col">HARI</th>
            <th colspan="3" scope="col">AKSI</th>
        </tr>
    </thead>
    <?php
        include 'koneksi.php';

            $query = mysqli_query($koneksi, "SELECT * FROM jadwal");
            $no = 1;
            while ($data = mysqli_fetch_assoc($query)) {
    ?>
        <tr>
            <td><?php echo $no++;?></td>
            <td><?php echo $data['kode'];?></td>
            <td><?php echo $data['makul'];?></td>
            <td><?php echo $data['dosen'];?></td>
            <td><?php echo $data['ruang'];?></td>
            <td><?php echo $data['hari'];?></td>
            <td>
                <i class="fas fa-edit bg-success p-2 text-white rounded"></i>
                <a href="ubah_jadwal.php?kode=<?php echo $data['kode'];?>">Edit</a>
                <i class="fas fa-trash-alt bg-danger p-2 text-white rounded"></i>
                <a href="hapus_jadwal.php?kode=<?php echo $data['kode'];?>">Delete</a>
            </td>
            </tr>
            

        <?php
            }
            ?>
    </table>
</div>
</div>
</body>
</html>


