<?php
session_start();
if (!isset($_SESSION["user"])){
    header("location: login.php");
    exit;
}

$user=$_SESSION['user'];
?>

<!DOCTYPE html>
<html>
    <head><title>Administrator</title></head>
<body>
        <h3>Selamat Datang <?php echo $user;?></h3>
        <h3>Jika Ingin Keluar <a href="keluar.php">Klik Sini</a></h3>
</body>
</html>   