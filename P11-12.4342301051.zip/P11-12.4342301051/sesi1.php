<?php
session_start();
?>

<!doctype html>
<html>
    <body>
        <?php
        $_SESSION["username"] = "admin";
        $_SESSION["password"] = "admin";

        echo "Variable sesi telah di ciptakan.";
        echo "<h2>Cek SESSION Klik <a href='sesi2.php'>Di Sini</h2>";
        ?>
   
</body>
</html>